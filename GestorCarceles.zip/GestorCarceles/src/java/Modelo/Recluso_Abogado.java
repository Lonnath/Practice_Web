/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Recluso_Abogado {
    int cod_recluso;
    long cedulaabogado;
    String fecha;

    public Recluso_Abogado(int cod_recluso, long cedulaabogado, String fecha) {
        this.cod_recluso = cod_recluso;
        this.cedulaabogado = cedulaabogado;
        this.fecha = fecha;
    }

    public int getCod_recluso() {
        return cod_recluso;
    }

    public void setCod_recluso(int cod_recluso) {
        this.cod_recluso = cod_recluso;
    }

    public long getCedulaabogado() {
        return cedulaabogado;
    }

    public void setCedulaabogado(long cedulaabogado) {
        this.cedulaabogado = cedulaabogado;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
}
