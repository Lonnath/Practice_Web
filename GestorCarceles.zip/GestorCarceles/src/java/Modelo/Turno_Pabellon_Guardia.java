/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Turno_Pabellon_Guardia {
 
    long cedula;
    int id_pabellon;
    String fecha;
    int id_carcel;
    String horaingreso;
    String  horasalida;

    public Turno_Pabellon_Guardia(long cedula, int id_pabellon, String fecha, int id_carcel, String horaingreso, String horasalida) {
        this.cedula = cedula;
        this.id_pabellon = id_pabellon;
        this.fecha = fecha;
        this.id_carcel = id_carcel;
        this.horaingreso = horaingreso;
        this.horasalida = horasalida;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public int getId_pabellon() {
        return id_pabellon;
    }

    public void setId_pabellon(int id_pabellon) {
        this.id_pabellon = id_pabellon;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getId_carcel() {
        return id_carcel;
    }

    public void setId_carcel(int id_carcel) {
        this.id_carcel = id_carcel;
    }

    public String getHoraingreso() {
        return horaingreso;
    }

    public void setHoraingreso(String horaingreso) {
        this.horaingreso = horaingreso;
    }

    public String getHorasalida() {
        return horasalida;
    }

    public void setHorasalida(String horasalida) {
        this.horasalida = horasalida;
    }
    
    
    
}
