/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Recluso {
    
    int cod_recluso;
    int telfonofamiliar;

    public Recluso() {
    }

    
    public Recluso(int cod_recluso, int telfonofamiliar) {
        this.cod_recluso = cod_recluso;
        this.telfonofamiliar = telfonofamiliar;
    }

    public int getCod_recluso() {
        return cod_recluso;
    }

    public void setCod_recluso(int cod_recluso) {
        this.cod_recluso = cod_recluso;
    }

    public int getTelfonofamiliar() {
        return telfonofamiliar;
    }

    public void setTelfonofamiliar(int telfonofamiliar) {
        this.telfonofamiliar = telfonofamiliar;
    }
    
    
}
