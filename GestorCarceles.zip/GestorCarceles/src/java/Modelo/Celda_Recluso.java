/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Celda_Recluso {
    int id_celda;
    int cod_recluso;
    int id_pabellon;

    public Celda_Recluso(int id_celda, int cod_recluso, int id_pabellon) {
        this.id_celda = id_celda;
        this.cod_recluso = cod_recluso;
        this.id_pabellon = id_pabellon;
    }

    public int getId_celda() {
        return id_celda;
    }

    public void setId_celda(int id_celda) {
        this.id_celda = id_celda;
    }

    public int getCod_recluso() {
        return cod_recluso;
    }

    public void setCod_recluso(int cod_recluso) {
        this.cod_recluso = cod_recluso;
    }

    public int getId_pabellon() {
        return id_pabellon;
    }

    public void setId_pabellon(int id_pabellon) {
        this.id_pabellon = id_pabellon;
    }
    
    
}
