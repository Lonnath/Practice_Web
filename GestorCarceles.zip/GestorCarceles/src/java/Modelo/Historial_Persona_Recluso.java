/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Historial_Persona_Recluso {
    long cedula;
    String fechaingreso;
    int cod_recluso;

    public Historial_Persona_Recluso(long cedula, String fechaingreso, int cod_recluso) {
        this.cedula = cedula;
        this.fechaingreso = fechaingreso;
        this.cod_recluso = cod_recluso;
    }

    public Historial_Persona_Recluso() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public String getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(String fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public int getCod_recluso() {
        return cod_recluso;
    }

    public void setCod_recluso(int cod_recluso) {
        this.cod_recluso = cod_recluso;
    }
    
    
}
