/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Pabellon {
    
    int id;
    int id_nivelriesgo;
    int id_carcel;

    public Pabellon(int id, int id_nivelriesgo, int id_carcel) {
        this.id = id;
        this.id_nivelriesgo = id_nivelriesgo;
        this.id_carcel = id_carcel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_nivelriesgo() {
        return id_nivelriesgo;
    }

    public void setId_nivelriesgo(int id_nivelriesgo) {
        this.id_nivelriesgo = id_nivelriesgo;
    }

    public int getId_carcel() {
        return id_carcel;
    }

    public void setId_carcel(int id_carcel) {
        this.id_carcel = id_carcel;
    }
    
    
}
