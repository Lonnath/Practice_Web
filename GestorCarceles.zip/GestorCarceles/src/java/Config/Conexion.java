/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Config;

import java.sql.*;
public class Conexion {
    
    public static void main(String [] args) throws ClassNotFoundException{
    
        String url ="jdbc:postgresql://localhost:5432/GestorCarceles";
        String usuario= "postgres";
        String contraseña = "admin04";
        
        try {
            Class.forName("org.postgresql.Driver");
            Connection conexion =DriverManager.getConnection(url,usuario,contraseña);
            java.sql.Statement st = conexion.createStatement();
            String sql 
                    = "SELECT cedula, nombre FROM Persona";
            ResultSet result = st.executeQuery(sql);
            while(result.next()){
        
               long cedula = result.getLong("cedula");
               String nombre  = result.getString("nombre");
                System.out.println("Cedula " + cedula + " Nombre " + nombre);
        }
            result.close();
            st.close();
            conexion.close();
            
        
        } catch (Exception e){
        
            System.out.println("Error de conexion "+ e.getMessage());
        }
    
    }
}
